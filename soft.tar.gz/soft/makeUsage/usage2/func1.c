#include <stdio.h>

int func1(void)
{
	printf("Func 1 Called!\n");
	printf("\n");
	return 0;
}
