#ifndef _FUNC1_H_
#define _FUCN1_H_


extern int func1(void);

#endif
