#include <stdio.h>

int func2(void)
{
	printf("func 2 Called!\n");
	return 0;
}
