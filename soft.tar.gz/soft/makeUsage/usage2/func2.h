#ifndef _FUNC2_H_
#define _FUNC2_H_

extern int func2(void);

#endif
