#include <stdio.h>
#include "func1.h"
#include "func2.h"
int main(void)
{
	printf("OK now!\n");
	func1();
	func2();
	return 0;
}
